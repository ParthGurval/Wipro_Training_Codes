package pract.BitWise;

public class NonReapeatingElements {

    // Method to find the two non-repeating elements in an array
    public static void nonReapElements(int[] arr) {
        
        int xorNum = 0, num1 = 0, num2 = 0; 
        // Purpose: Initialize variables. Explanation: `xorNum` will store the XOR of all elements, `num1` and `num2` will store the two non-repeating elements.
        
        
        // XOR all elements in the array to get XOR of the two non-repeating elements
        for(int num : arr) { // Purpose: Iterate through all elements in the array. Explanation: This loop calculates the XOR of all elements.
            xorNum ^= num; 
            // Purpose: XOR each element with `xorNum`. Explanation: This operation will cancel out the elements that appear twice, 
            // leaving XOR of the two unique elements.
        }
        
        // Get the rightmost set bit in xorNum
        int rMostBit = xorNum & (-xorNum); 
        // Purpose: Isolate the rightmost set bit. Explanation: `xorNum & (-xorNum)` isolates the rightmost bit that is set to 1 in `xorNum`.
        
        
        // Divide the elements into two groups based on the rightmost set bit
        for(int num : arr) { // Purpose: Iterate through all elements again. 
        	//Explanation: This loop separates elements into two groups based on the isolated bit.
        	
            if((num & rMostBit) == 0) { 
            	// Purpose: Check if the rightmost set bit is 0. Explanation: If true, the element belongs to the first group.
            	
                num1 ^= num; // Purpose: XOR the element with `num1`. Explanation: This operation accumulates the XOR of elements in the first group, 
                // resulting in one of the non-repeating elements.
                
            } else { // Purpose: Handle elements where the rightmost set bit is 1. Explanation: These elements belong to the second group.
            	
                num2 ^= num; 
                // Purpose: XOR the element with `num2`. Explanation: This operation accumulates the XOR of elements in the second group, 
                // resulting in the other non-repeating element.
            }
        }
        
        // Print the two non-repeating elements
        System.out.println("The two Non-Repeating Elements are: " + num1 + " & " + num2); 
        // Purpose: Output the results. Explanation: This prints the two unique elements found in the array.
    }
    
    public static void main(String[] args) {
        // Test case
        int[] array = { 2, 3, 7, 9, 11, 2, 3, 11 }; 
        // Purpose: Define the test array. Explanation: This array contains the numbers with two non-repeating elements.
        
        // Find and print the two non-repeating elements
        nonReapElements(array); 
        // Purpose: Call the method to find and print the non-repeating elements. Explanation: Executes the `nonReapElements` 
        // method with the test array as input.
    }
}
