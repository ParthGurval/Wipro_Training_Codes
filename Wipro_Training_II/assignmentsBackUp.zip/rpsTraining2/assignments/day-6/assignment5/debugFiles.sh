#!/bin/bash

debug=true

dir_name="TestDir"
file_prefix="File"
file_extension=".txt"

debug_msg() {

	if [ "debug" == true ] ; then
		echo "[DEBUG] $1"
	fi
}

if mkdir -p "$dir_name" 2>/dev/null; then
	echo "Directory '$dir_name' created."
	debug_msg "Successfully created or already exists: $dir_name"
else
	echo "Error: Unable to Create directory '$dir_name' Check Permission"
	debug_msg "Failed to create directory: $dir_name"
	exit 1
fi

for i in {1..10}; do
	file_name="${file_prefix}${i}${file_extension}"
	if echo "$file_name" > "${dir_name}/${file_name}" 2>/dev/null; then
		echo "File '$file_name' created with content '$file_name'."
		debug_msg "File Created: ${dir_name}/${file_name}"
	else
		echo "Error: Unable to create file: '${dir_name}/${file_name}'. Check Permission"
		debug_msg "Failed to Create files: ${dir_name}/${file_name}"
	exit 1
	fi
done

echo "Directory '$dir_name' and files created sucessfully."
debug_msg "Script execution has done Successfully"


