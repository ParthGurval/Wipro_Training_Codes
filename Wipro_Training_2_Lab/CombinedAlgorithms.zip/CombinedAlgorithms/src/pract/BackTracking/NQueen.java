package pract.BackTracking;


//The goal of the N-Queen problem is to place n queens on an n x n chessboard such that no two queens threaten each other.

public class NQueen {
	
//	final int n = 4;: This defines the size of the chessboard (n x n). The final keyword means that n is a constant and cannot be changed once initialized.	
	final int n = 4;
	
//	Method: printSoln(int board[][])
//	Purpose: This method prints the current configuration of the chessboard.
//	Parameters: It takes a 2D array board representing the chessboard.
//	Logic: It iterates through the board and prints each element, with \t used to separate elements in a row, making the output easier to read.
	void printSoln(int board[][]) {
		
		for(int x  = 0; x < n; x++) {
			
			for(int y = 0; y < n; y++) {
				
				System.out.print(board[x][y] + "\t");
			}
			
			System.out.println();
		}
	}

//	Purpose: This method checks whether it's safe to place a queen at position (row, col) on the chessboard.
	boolean isSafe(int board[][], int row, int col) {
		
		int i, j;
		
//		It checks three directions:



//		The left side of the current row.
		for(i = 0; i < col; i++) {
			
//			If any of these positions already have a queen (board[i][j] == 1), it's not safe to place another queen, and the method returns false.	
			if(board[row][i] == 1) {
				
				return false;
			}
		}
		
//		The upper left diagonal.
		for(i = row, j = col; i >= 0 && j >= 0; i--, j--) {
			
//			If any of these positions already have a queen (board[i][j] == 1), it's not safe to place another queen, and the method returns false.	
			if(board[i][j] == 1) {
				
				return false;
			}
		}
		
//		The lower left diagonal.
		for(i = row, j = col; j >= 0 && i < n; i++, j--) {
			
//			If any of these positions already have a queen (board[i][j] == 1), it's not safe to place another queen, and the method returns false.	
			if(board[i][j] == 1) {
				
				return false;
			}
		}
		
//		If all checks pass, the method returns true, indicating that the position is safe.
		return true;
	}
	
//	Purpose: This is the main recursive method to solve the N-Queen problem using backtracking.
//	Parameters: It takes the current state of the board and the column where the next queen needs to be placed.
	boolean fnlNQUtil(int board[][], int col) {
		
//		Base Case: If all columns are filled (col >= n), it returns true, indicating that a solution has been found.
		if(col >= n) {
			
			return true;
		}
		
//		Recursive Case: For each row in the current column:
		for(int i = 0; i < n; i++) {
			
//			It checks if placing a queen is safe using the isSafe method.
			if(isSafe(board, i, col)) {
				
//				If safe, it places a queen (board[i][col] = 1).
				board[i][col] = 1;
				
//				It then recursively calls itself to place the next queen in the next column.
				if(fnlNQUtil(board, col + 1)) {
					
					return true;
				}
				
//				If placing the next queen fails, it backtracks by removing the queen (board[i][col] = 0).
				board[i][col] = 0; //backtracking
			}
		}
		
//		If no placement works, it returns false.
		return false;
	}
	
//	Purpose: This method sets up the board and initiates the backtracking process.
	boolean resultNQ() {
		
//		It initializes the board as a n x n grid filled with zeros.
		int board[][] = new int[n][n];
		
//		It calls fnlNQUtil to start placing queens from the first column.
		if(!fnlNQUtil(board, 0)) {
			
//			If no solution exists, it prints a message; otherwise 
			System.out.println("Solution does not exist");
			return false;
		}
		
//		it prints the solution.
		printSoln(board);
		return true;
	}
	
//	Purpose: The entry point of the program.
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		It creates an instance of the NQueen class.
		NQueen Queen = new NQueen();
		
//		It calls resultNQ() to find and print a solution for the N-Queen problem.
		Queen.resultNQ();
	}

}

	//This code solves the N-Queen problem using backtracking.
	//It places queens one by one in different columns, ensuring that no two queens can attack each other.
	//If it finds a valid placement for all queens, it prints the solution; otherwise, it backtracks and tries a different arrangement.
