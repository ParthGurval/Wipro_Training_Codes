#!/bin/bash

echo "Please enter the number"

read inpNum

num=1

while [ $num -le $inpNum ]; do
	echo "The Number is: " $num
	num=$(($num+1))
done
