package pract.SearchingAlgo;

// Define the class for linear search example
public class LinearSearchExp {

    // Method to perform linear search on an array
    public static int linSearch(int[] array, int x) {
        // Loop through each element in the array
        for(int i = 0; i < array.length; i++) {
            // Check if the current element is equal to the target value x
            if(array[i] == x) {
                return i; // Return the index of the found element
            }
        }
        // Return -1 if the element is not found in the array
        return -1;
    }
    
    public static void main(String[] args) {
        // Define an array of integers to search
        int[] num = {0, 5, 10, 15, 20, 900, 25, 50, 100, 150, 200, 75, 400};
        
        // Define the target number to search for
        int x = 200;
        
        // Call the linear search method and store the result
        int res = linSearch(num, x);
        
        // Check if the number was found and print the appropriate message
        if(res != -1) {
            System.out.println("The given number " + x + " is found at index: " + res);
        } else {
            System.out.println("Number is not present in the array");
        }
    }
}
