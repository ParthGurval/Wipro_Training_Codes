package pract.ComputationalAlgorithms;

public class TowerOfHanoi {

    // Purpose: Solve the Tower of Hanoi problem using recursion
    // Parameters:
    //   - int n: The number of disks to move
    //   - char fromRod: The rod from which the disk is to be moved
    //   - char toRod: The rod to which the disk is to be moved
    //   - char auxRod: The auxiliary rod used for temporary storage
    static void solveHanoi(int n, char fromRod, char toRod, char auxRod) {

        // Purpose: Base case for the recursion, handle the simplest case where only one disk is to be moved
        if (n == 1) {
            // Explanation: If there is only one disk, move it directly from the source rod to the target rod
            System.out.println("Moving Disk 1 from rod " + fromRod + " to rod " + toRod);
            return; // Purpose: End the recursion for this branch as the disk has been moved
        }

        // Purpose: Recursively move n-1 disks from the source rod to the auxiliary rod using the target rod as a temporary storage
        solveHanoi(n - 1, fromRod, auxRod, toRod); // Explanation: Move the top n-1 disks to the auxiliary rod

        // Purpose: Move the nth disk (largest) from the source rod to the target rod
        System.out.println("Move disk " + n + " from rod " + fromRod + " to rod " + toRod);

        // Purpose: Recursively move the n-1 disks from the auxiliary rod to the target rod using the source rod as a temporary storage
        solveHanoi(n - 1, auxRod, toRod, fromRod); // Explanation: Move the n-1 disks from the auxiliary rod to the target rod
    }

    public static void main(String[] args) {
        // Purpose: Main method to start the execution of the Tower of Hanoi solution

        int numDisk = 3; // Purpose: Define the number of disks to be moved in the Tower of Hanoi problem
        System.out.println("Tower of Hanoi has " + numDisk + " Disks");

        // Purpose: Call the solveHanoi method to solve the Tower of Hanoi problem for the given number of disks
        solveHanoi(numDisk, 'A', 'C', 'B'); // Explanation: Start the process of moving the disks from rod A to rod C using rod B as auxiliary
    }

}

