package com.wipro.students.application;

import java.util.Scanner;

public class Student {

	int age;
	
	public void userInput() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Please Enter You'r Age: ");
		age = sc.nextInt();
		
		sc.close();
	}
	
	public void verifyStud() throws UnderAgeException, OverAgeException {
		
		if(age < 17) {
			
			throw new UnderAgeException("Sorry, You are too young to entroll in the University, Please wait untill you turn 17.");
			
		}
		
		else if(age > 25) {
			
			throw new OverAgeException("Sorry, You are too old to entroll in the university, Please Contact the admission office for further assistance.");
			
		}
		
		else {
			
			System.out.println("Congrats, You are now Eligible to entroll in the University");
		}
	}
}
