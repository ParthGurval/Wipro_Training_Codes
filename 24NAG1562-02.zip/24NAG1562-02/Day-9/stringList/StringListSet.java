/*
  Write a simple java program that accepts List of Strings from user
  The program should accept the input strings until user enter exit
  After collecting string log the Strings and the strings at the
  odd indices should be reversed in final output   
 
 */


package com.wipro.stringList;

import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class StringListSet {
	
	private static String reverseString(String str) {
		
		StringBuilder sb = new StringBuilder(str);
		return sb.reverse().toString();
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		List<String> strList = new ArrayList<>();
		
		System.out.println("Please Enter the String (Type 'exit' to close): ");
		
		
		while(true) {
			
			String inp = sc.nextLine();
			
			if(inp.equalsIgnoreCase("exit")) {
				
				break;
			}
			
			strList.add(inp);
		}
		
		
		
		for(int i = 0; i < strList.size(); i++) {
			
			if(i % 2 != 0) {
				
				String currString = strList.get(i);
				String reverseStr = reverseString(currString);
				
				strList.set(i, reverseStr);
			}
		}
		
		System.out.println("Modified String list is: ");
		System.out.println(strList);
	}
	
}
