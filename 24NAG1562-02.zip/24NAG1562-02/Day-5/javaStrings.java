
// 2.Write a method that takes a string, converts all characters to uppercase, and then returns the string with alternating uppercase and lowercase characters.

//Task 2: 


public class javaStrings {
    
    public static void main(String[] args){
        
        String msg = "Hello World";
        String res = alterString(msg);
        System.out.println(res);
    }
    
    public static String alterString(String str){
        
        String upperString = str.toUpperCase();
        
        String result = "";
        
        for(int i = 0; i < upperString.length(); i++){
            
            char currStrChar = upperString.charAt(i);
            
            if(Character.isLetter(currStrChar) || Character.isDigit(currStrChar)){
                
                if(i % 2 == 0){
                    
                    result = result + currStrChar;
                }
                else{
                    result = result + Character.toLowerCase(currStrChar);
                }
            }
            else{
                    result = result + currStrChar;
            }

        }
        
        return result; 
    }
}