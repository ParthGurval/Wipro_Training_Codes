package com.wipro.students.application;

public class UniversityLaunch {

	public static void main(String[] args) {
		
		University uni = new University();
		uni.initiate();
	}
}
