package com.wipro.students.application;

public class University {

	public void initiate() {
		
		Student stud = new Student();
		
		stud.userInput();
		
		try {
			stud.verifyStud();
		}
		catch(UnderAgeException uae){
			
			uae.printStackTrace();
		}
		catch(OverAgeException oae){
			
			oae.printStackTrace();
		}
	}
}
