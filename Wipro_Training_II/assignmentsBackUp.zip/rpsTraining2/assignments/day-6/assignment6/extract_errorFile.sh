#!/bin/bash

# Assignment 6

log_files="demo.log"

if [ ! -f "$log_files" ] ; then
	echo "LOg file '$log_file' not Found!!"
	exit 1
fi

#we use for search
grep "ERROR" "$log_files" | awk '{print $1, $2, $0}' | sed 's/ERROR/ERROR:/g'

