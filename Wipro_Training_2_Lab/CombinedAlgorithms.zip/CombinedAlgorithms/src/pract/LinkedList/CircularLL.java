package pract.LinkedList; // Declares the package name

// Class to represent a node in the Circular Linked List
class Node {
    int data;      // Data held by the node
    Node next;     // Reference to the next node in the list
    
    // Constructor to initialize a node with data
    Node(int data) {
        this.data = data; // Initializes the node with the given data
        this.next = null; // Sets the next pointer to null (no next node yet)
    }
}

// Class to represent a Circular Linked List
class CircularLL {
    Node head;     // Reference to the first node in the list
    
    // Method to insert a new node with given data into the circular linked list
    void insert(int data) {
        Node newNode = new Node(data);  // Create a new node with the given data
        
        // If the list is empty, make the new node the head and point it to itself
        if (head == null) {
            head = newNode;            // Assign the new node as the head
            newNode.next = head;       // Point the new node's next to itself (circular reference)
        } else {
            Node temp = head;          // Start from the head node
            // Traverse to the last node (the one which points to head)
            while (temp.next != head) { 
                temp = temp.next;      // Move to the next node until the last node is found
            }
            // Insert the new node at the end of the list
            temp.next = newNode;       // Link the last node to the new node
            newNode.next = head;       // Point the new node to the head to maintain the circular structure
        }
    }
    
    // Method to display all nodes in the circular linked list
    void display() {
        // If the list is empty, simply return
        if (head == null) return;       // Exit if the list is empty
        
        Node temp = head;               // Start from the head node
        // Traverse and print each node's data until we come back to the head
        do {
            System.out.print(temp.data + " "); // Print the data of the current node
            temp = temp.next;                 // Move to the next node
        } while (temp != head);               // Continue until the loop reaches the head node again
        System.out.println();                 // Print a newline after displaying the list
    }
    
    public static void main(String[] args) {
        CircularLL list = new CircularLL(); // Create a new circular linked list
        list.insert(1); // Insert nodes with data 1, 2, and 3
        list.insert(2);
        list.insert(3);
        list.display(); // Display the circular linked list: Output: 1 2 3
    }
}
