package com.wipro.banking.application;

import java.util.Scanner;

public class bankApplication {

	public static void main(String[] args) {
		
		BankAccount bnkAcc = new BankAccount(100000);
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter the withdrawl Amount: $");
		double wdlAmount = sc.nextDouble();
		
		try {
			
			bnkAcc.withdraw(wdlAmount);
		}
		catch(InsufficientFundsException ife) {
			
			System.out.println("Exception: "+ife.getMessage());
		}
		
		System.out.println("Available Balance is: $ "+ bnkAcc.getBalance());
	}
}
