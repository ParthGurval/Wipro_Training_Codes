package pract.DynamicProgrammingAlgorithms;

public class KnapSackDPA {

    // Method to solve the 0/1 Knapsack problem using dynamic programming
    static int knapSack(int W, int[] wt, int[] val, int n) {
//    	Parameters:
//    		W: The maximum capacity of the knapsack.
//    		wt: An array where wt[i] represents the weight of the i-th item.
//    		val: An array where val[i] represents the value of the i-th item.
//    		n: The number of items.
    	
        // Create a 2D array to store the maximum value that can be obtained
        // dp[i][w] will be the maximum value that can be obtained with the first i items and capacity w
        int[][] dp = new int[n + 1][W + 1];
//        n + 1
//        Purpose: To handle the case where no items are considered.
//        Explanation:
//        n is the number of items.
//        By creating an array of size n + 1, you account for the scenario where you have 0 items.
//        The +1 allows indexing from 0 to n, representing each possible number of items from 0 up to n.

        //        W + 1
//        Purpose: To handle the case where the knapsack has 0 capacity.
//        Explanation:
//        W is the maximum capacity of the knapsack.
//        By creating an array of size W + 1, you account for capacities ranging from 0 to W.
//        The +1 allows indexing from 0 to W, representing each possible capacity from 0 up to W.

        // Iterate over all items (i from 0 to n) and all capacities (w from 0 to W)
        for (int i = 0; i <= n; i++) {
            for (int w = 0; w <= W; w++) {
            	
 //           	Purpose: When there are no items (i == 0) or the knapsack has zero capacity (w == 0), the maximum value is 0.
            	// With no items or no capacity, you can't add any value.
                if (i == 0 || w == 0) {
                    dp[i][w] = 0;
 //                   dp[i][w]: Represents the maximum value that can be achieved with the first i items and a knapsack capacity of w.
                } 
                
                // If the weight of the current item is less than or equal to the current capacity
                else if (wt[i - 1] <= w) {
                    // Calculate the maximum value by including or excluding the current item
                    // max(value of including the item, value of excluding the item)
                    dp[i][w] = Math.max(val[i - 1] + dp[i - 1][w - wt[i - 1]], dp[i - 1][w]);
 //          1         dp[i][w]: Represents the maximum value that can be achieved with the first i items and a knapsack capacity of w.
//           2         val[i - 1] + dp[i - 1][w - wt[i - 1]]: This is the value if you include the current item (item i). 
//                    It adds the item's value to the maximum value achievable with the remaining capacity (w - wt[i - 1]) from the previous items.
                    
//            3        dp[i - 1][w]: This is the value if you exclude the current item, meaning you just take the maximum value achievable with the first i - 1 
//                    items and the same capacity w.
                    
                } 
                // If the weight of the current item is more than the current capacity
                else {
                    // Exclude the current item (value remains the same as without this item)
                    dp[i][w] = dp[i - 1][w];
                }
            }
        }

        // Return the maximum value that can be obtained with n items and capacity W
        return dp[n][W];
    }

    // Main method to test the knapSack method
    public static void main(String[] args) {
        int W = 10; // Capacity of the knapsack
        int[] val = {10, 40, 30, 50}; // Values of the items
        int[] wt = {5, 4, 6, 3}; // Weights of the items
        int n = val.length; // Number of items

        // Call the knapSack method and print the result
        System.out.println("Maximum value in Knapsack = " + knapSack(W, wt, val, n));
    }
}

