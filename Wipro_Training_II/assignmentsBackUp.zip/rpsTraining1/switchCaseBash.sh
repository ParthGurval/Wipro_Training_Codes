#!/bin/bash

echo "Pease enter name of fruit: "

read fruit

case $fruit in
	apple)
		echo "Fruit is from apple list"
		;;
	banana)
		echo "Fruit is from banana list"
		;;
	*)
		echo "Fruit is $fruit default list"
		;;
esac
