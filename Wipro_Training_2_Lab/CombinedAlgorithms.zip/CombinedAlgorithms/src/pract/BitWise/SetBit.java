package pract.BitWise;

import java.util.Scanner;

public class SetBit {

    public static void main(String[] args) {
        // Create a Scanner object to read input from the user
        Scanner sc = new Scanner(System.in);
        
        // Prompt the user to enter a number
        System.out.print("Please Enter a Number: ");
        int num = sc.nextInt(); // Read the user input
        sc.close(); // Close the Scanner to prevent resource leaks
        
        int count = 0; // Variable to store the count of set bits
        
        // Print initial number
        System.out.println("Initial Number: " + num);
        
        // Loop to count the number of set bits
        while(num > 0) {
            // Print the current state of num and the least significant bit check
            System.out.println("Current Number: " + num + ", LSB Check: " + (num & 1));
            
            count += num & 1; // Check if the least significant bit is set and add to count
            
            num >>= 1; // Right shift the number to process the next bit
            
            // Print the state of num after right shift
            System.out.println("Number after Right Shift: " + num);
        }
        
        // Print the number of set bits
        System.out.print("Number of set bits: " + count);
    }
}
