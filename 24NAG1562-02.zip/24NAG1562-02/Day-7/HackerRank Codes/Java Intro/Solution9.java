
// Java End-of-File

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution9 {

    public static void main(String[] args) {
        
        
        Scanner sc = new Scanner(System.in);
        
        int i = 0;
        
            while(sc.hasNext()){
                
                i++;
                
                System.out.println(i+ " " + sc.nextLine());
            }
        sc.close();
    }
}