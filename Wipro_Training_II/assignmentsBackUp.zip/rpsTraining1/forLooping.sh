#!/bin/bash

for i in {0..15..3}
do
	echo $i
done

echo "Enter Number"
read num
for (( c=1; c<=$num; c++ ))
do
	echo $c
done
