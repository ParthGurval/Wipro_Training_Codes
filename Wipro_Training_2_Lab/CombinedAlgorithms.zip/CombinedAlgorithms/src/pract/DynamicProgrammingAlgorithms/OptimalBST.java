package pract.DynamicProgrammingAlgorithms;

public class OptimalBST {

    // Purpose: Function to calculate the cost of the Optimal Binary Search Tree (BST)
//	keys: This is an array of integers representing the keys or values that will be used to construct the optimal binary search tree (BST). 
//	Each element in this array is a key that will be inserted into the BST.
//
//	n: This is an integer representing the number of keys in the keys array. It denotes the size of the array and is used to determine the 
//	dimensions of the cost matrix and the range of subtrees to be considered.
    static int optimalBST(int[] keys, int n) {
        // Purpose: Create a 2D array to store the cost of optimal BST for keys[i...j]
        int[][] cost = new int[n][n];
//        int[n][n] creates a 2D array with n rows and n columns, where each element is of type int. 
//        It initializes a square matrix of size n x n for storing integer values.

        // Purpose: Initialize the diagonal elements of the cost matrix (single key) to 0
        for (int i = 0; i < n; i++) {
            cost[i][i] = 0;  // Single key costs 0 as there are no left or right subtrees
        }

        // Purpose: Fill the cost matrix for subtrees of increasing lengths
        for (int length = 2; length <= n; length++) {  // length of the subtree
            for (int i = 0; i <= n - length; i++) {  // start index of the subtree
                int j = i + length - 1;  // end index of the subtree
                cost[i][j] = Integer.MAX_VALUE;  // Initialize cost to a large value

                // Purpose: Find the optimal root for the subtree keys[i...j]
                for (int r = i; r <= j; r++) {  // Try each key as the root
                    // Purpose: Calculate cost if r is the root of the subtree keys[i...j]
                    int c = ((r > i) ? cost[i][r - 1] : 0) +  // Cost of left subtree
                            ((r < j) ? cost[r + 1][j] : 0) +  // Cost of right subtree
                            sum(keys, i, j);  // Cost of keys[i...j]

                    // Purpose: Update cost[i][j] with the minimum cost found
                    if (c < cost[i][j]) {
                        cost[i][j] = c;  // Set the optimal cost for keys[i...j]
                    }
                }
            }
        }

        // Purpose: Return the cost of the optimal BST for the entire range keys[0...n-1]
        return cost[0][n - 1];
    }

    // Purpose: Calculate the sum of keys[i...j]
//    i: This is the starting index of the range within the keys array for which the sum is to be calculated. It indicates the beginning of the subset of keys.
//
//    j: This is the ending index of the range within the keys array for which the sum is to be calculated. It indicates the end of the subset of keys.
    static int sum(int[] keys, int i, int j) {
        int s = 0;  // Initialize sum to 0
        for (int k = i; k <= j; k++) {
            s += keys[k];  // Add each key to the sum
        }
        return s;  // Return the total sum
    }

    // Purpose: Main function to test the optimalBST function
    public static void main(String[] args) {
        int[] keys = {10, 20, 30, 40, 50, 60, 70};  // Array of keys
        int n = keys.length;  // Number of keys

        // Purpose: Print the cost of the optimal BST for the given keys
        System.out.println("The Cost of Optimal BST is " + optimalBST(keys, n));
    }
}

