package pract.PatternSearching;

public class NaiveStringMatch {

//	Purpose: This method searches for occurrences of pattern within text.
//	Variables:
//	text (String): The main text where we are searching.
//	pattern (String): The substring we are looking for in text.
	void search(String text, String pattern) {

		int n = text.length();
		int m = pattern.length();
//		Purpose: Initialize the lengths of text and pattern.
//		Variables:
//		n (int): Length of text.
//		m (int): Length of pattern.
		
//		Purpose: Loop through text to check each possible starting position for pattern.
//		Variables:
//		i (int): Starting index in text from which to compare pattern.
		for(int i = 0; i <= n - m; i++) {
			
			int j;
//			Purpose: Declare a variable for iterating through characters in pattern.
//			Variables:
//			j (int): Index for traversing pattern.
			
			
//			Purpose: Compare characters of text and pattern starting from index i.
//			Variables:
//			j (int): Index for traversing pattern and checking against text.
			for(j = 0; j < m; j++) {
				
				
//				Purpose: Check if characters match. If not, exit the inner loop.
//				Explanation:
//				text.charAt(i + j) retrieves the character at position i + j in text.
//				pattern.charAt(j) retrieves the character at position j in pattern.
//				If they do not match, break exits the inner loop.
				if(text.charAt(i + j) != pattern.charAt(j)) {
					
					break;
				}
			}
			
//			Purpose: If all characters in pattern have been matched (j == m), print the starting index i.
//			Explanation: j == m means pattern matches a substring in text starting at index i.
			if(j == m) {
				
				System.out.println("Pattern Found at Index "+ i);
			}
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Purpose: Create an instance of NaiveStringMatch to call the search method.
		NaiveStringMatch nsm = new NaiveStringMatch();
		
//		Purpose: Test the search method with txt1 and pat1. Print the results.
		String txt1 = "AABAACAADAABAABA";
		String pat1 = "AABA";
		System.out.println("Example: 1");
		nsm.search(txt1, pat1);
		
//		Purpose: Test the search method with txt2 and pat2. Print the results.
		String txt2 = "agd";
		String pat2 = "g";
		System.out.println("\nExample: 2");
		nsm.search(txt2, pat2);
	}

}

