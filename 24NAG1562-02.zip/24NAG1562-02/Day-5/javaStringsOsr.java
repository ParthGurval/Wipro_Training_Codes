

// 3.Write a method that takes a string and a character, removes all occurrences of the character from the string, and returns the result.


// Task: 3

import java.util.Scanner;

public class javaStringsOsr {
    
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter a String: ");
        String userString = sc.nextLine();
        
        System.out.print("Enter a character to remove: ");
        char rmCharacter =  sc.next().charAt(0);
        
        String result = removeCharString(userString, rmCharacter);
        System.out.print("String after removing character is: "+result);

        sc.close();
    }
    
    public static String removeCharString(String str, char remChar){
        
        String storeStr = "";
        
        for(int i = 0; i < str.length(); i++){
            
            char currChar = str.charAt(i);
            
            if(currChar != remChar){
                
                storeStr = storeStr + currChar;
            }
        }
        
        return storeStr;
    }
}