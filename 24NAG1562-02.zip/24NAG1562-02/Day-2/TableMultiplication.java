/*
 Code For Multiplication Table with range 

Generating Multiplication table
 
- take the number and range as input
 
input:
number = 5
range = 10
 
output:
5 * 1 = 5
5 * 2 = 10
5 * 3 = 15
--
--
--
5 * 10 = 50

 */

import java.util.Scanner;

public class TableMultiplication{

	public static void main(String[] args){
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please Enter The Number: ");
		int number = sc.nextInt();
		
		System.out.println("Please Enter The Ranger");
		int range = sc.nextInt();
		
		for(int i=1; i<= range; i++){
			
			int result = number * i;
			System.out.println("The Table of Given Number"+number+"with range of"+range+"is:");
			System.out.println(number + "*" + i + "=" + result);
		
		}
		
		sc.close();
	
	}

}


/* 
Using While loop

 class TableMulti {
	public static void main(String[] args)
	{
		
		int N = 7;

		int range = 18;

		int i = 1;

		while (i <= range) {

			System.out.println(N + " * " + i + " = "+ N * i);
			i++;
		}
	}
}

*/