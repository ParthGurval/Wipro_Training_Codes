package com.wipro.banking.application;

import java.util.Scanner;

public class bankApplication {

	public static void main(String[] args) {
		
		BankAccount bnkAcc = new BankAccount(1000);
		
		Scanner sc = new Scanner(System.in);
		
		int choice; 
		
		do {
			
			System.out.println("----- Please Select An Option -----");
			System.out.println("1. Withdraw Money");
			System.out.println("2. Deposit Money");
			System.out.println("3. Show Balance");
			System.out.println("-----------------------------------");
			System.out.print("Please Enter Your Choice: ");
			choice = sc.nextInt();		
			System.out.println();
			switch(choice) {
			
			case 1:
					
					System.out.print("Please Enter the withdrawl Amount: $");
					double wdlAmount = sc.nextDouble();
					
					try {
						
						bnkAcc.withdraw(wdlAmount);
					}
					catch(InsufficientFundsException ife) {
						
						System.out.println("Exception: "+ife.getMessage());
					}
					
				break;
				
			case 2:
				
				System.out.print("Enter Amount you want to Deposit: $");
				double depAmount = sc.nextDouble();
				bnkAcc.deposit(depAmount);
				
				System.out.println("Deposited Amount: $"+depAmount);
				
				break;
			
			case 3:
				
				System.out.println("Total Available Balance: $"+bnkAcc.getBalance());
				
				break;
				
			default:
				
				System.out.println("Invalid Choice.... \nPlease Try Again....");
				
				break;
			}
			
			System.out.println();
			
			System.out.println("To Continue Press 1, \nTo EXIT Press 0 ");
			choice = sc.nextInt();
		}
		
		while(choice == 1);
			
			sc.close();	

	}
}
