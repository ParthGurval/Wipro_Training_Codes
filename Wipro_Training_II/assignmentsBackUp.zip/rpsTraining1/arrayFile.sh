#!/bin/bash

myArray=(1 2 3 4 5)

echo  ${myArray[4]}

	for num in ${myArray[@]}; do
		echo $num
done
