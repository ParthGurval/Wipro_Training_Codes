
// 1.Write a method that takes two strings, concatenates them, reverses the result.

// Task: 1


public class coonectSting {

    public static void main(String[] args) {
        
        String str1 = "Parth";
        String str2 = "WebDeveloper";
        
        System.out.println("First String is: " + str1);
        System.out.println("Second String is: " + str2);
        
        String res1 = concatString(str1, str2);
        System.out.println("\nConcatenated String is: " + res1);
        
        String result = reverseString(res1);
        System.out.println("\nReversed String is: " + result);
        
    }
    
    public static String concatString(String str1, String str2) {
        return str1 + str2;
    }
    
    public static String reverseString(String str) {
        String reverseStr = "";
        
        for (int i = str.length() - 1; i >= 0; i--) {
            reverseStr = reverseStr + str.charAt(i);
        }
        
        return reverseStr;
    }
}