#!/bin/bash

file=/home/rps/Desktop/rpsTraining1/abc.txt

if [ -f $file ] ; then
	echo "yes"
fi

cat abc.txt  rpsTrain.txt | sort

echo $?

mkdir
echo $?
