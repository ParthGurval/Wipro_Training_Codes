#!/bin/bash

count_lines() {

	local filename=$1
	if [[ -f  $filename && -r $filename ]]; then
		local line_count=$(wc -l< "$filename")
		echo "The number of lines in file '$filename' is: '$line_count'"
	else
		echo "File '$filename' doesn't exist"
	fi
}

echo "Checking Number of Lines in file..."

count_lines "file1.txt"
count_lines "file2.txt"
count_lines "file3.txt"
count_lines "file4.txt"
count_lines "file5.txt"

