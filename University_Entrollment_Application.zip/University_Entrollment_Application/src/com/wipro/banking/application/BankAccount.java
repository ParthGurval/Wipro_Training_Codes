package com.wipro.banking.application;



public class BankAccount {

	double balance;
	
	//Constructor	
	public BankAccount(double previousBalance) {
		
		balance = previousBalance;
	}
	
	public void deposit(double amount) {
		
		balance = balance + amount;
		System.out.println("Your "+ amount + "has been successfully Deposited.");
	}
	
	public void withdraw(double amount) throws InsufficientFundsException {
		
		if(amount > balance) {
			
			throw new InsufficientFundsException("Insufficient Balance...!!! "+"\n The amount $ "+ amount + " exceeds account balance: $" + balance);
		}
		
		balance = balance - amount;
		System.out.println("$ "+amount+" has been successfully withdrawn from your account. ");
	}
	
	public double getBalance() {
		return balance;
	}
}
