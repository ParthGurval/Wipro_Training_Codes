package pract.Queue; // Declares the package name

// SimpleQueue.java
public class SimpleQueue {
    private int[] queue; // Array to store queue elements
    private int front, rear, size, capacity; // Variables to track the front, rear, size, and capacity of the queue
    
    // Constructor to initialize queue
    public SimpleQueue(int capacity) {
        this.capacity = capacity; // Sets the queue capacity
        queue = new int[capacity]; // Initializes the queue array with the specified capacity
        front = 0; // Initializes the front pointer to 0
        rear = -1; // Initializes the rear pointer to -1 (indicating the queue is empty)
        size = 0; // Initializes the size of the queue to 0
    }
    
    // Enqueue operation
    public void enqueue(int value) {
        if (size == capacity) { // Checks if the queue is full
            System.out.println("\nQueue Overflow"); // Prints a message if the queue is full
            return; // Exits the method to prevent overflow
        }
        rear = (rear + 1) % capacity; // Moves the rear pointer forward, wrapping around if necessary
        queue[rear] = value; // Adds the new value to the rear of the queue
        size++; // Increments the size of the queue
        System.out.println("\n" + value + " added to queue"); // Prints a message indicating the value added to the queue
    }
    
    // Dequeue operation
    public int dequeue() {
        if (size == 0) { // Checks if the queue is empty
            System.out.println("\nQueue Underflow"); // Prints a message if the queue is empty
            return -1; // Returns -1 to indicate underflow
        }
        int value = queue[front]; // Stores the front element of the queue
        front = (front + 1) % capacity; // Moves the front pointer forward, wrapping around if necessary
        size--; // Decrements the size of the queue
        return value; // Returns the dequeued value
    }
    
    // Peek operation
    public int peek() {
        if (size == 0) { // Checks if the queue is empty
            System.out.println("\nQueue is empty"); // Prints a message if the queue is empty
            return -1; // Returns -1 to indicate the queue is empty
        }
        return queue[front]; // Returns the front element of the queue without removing it
    }
    
    // Check if queue is empty
    public boolean isEmpty() {
        return size == 0; // Returns true if the queue size is 0, indicating the queue is empty
    }
    
    // Display the queue elements
    public void display() {
        if (size == 0) { // Checks if the queue is empty
            System.out.println("Queue is empty"); // Prints a message if the queue is empty
            return; // Exits the method
        }
        System.out.print("Queue elements: "); // Prints the queue elements
        for (int i = 0; i < size; i++) { // Iterates over the queue elements
            System.out.print(queue[(front + i) % capacity] + " "); // Prints each element using circular indexing
        }
        System.out.println(); // Moves to the next line after printing all elements
    }
    
    public static void main(String[] args) {
        // Create a queue of size 5
        SimpleQueue queue = new SimpleQueue(5); // Initializes a queue with a capacity of 5
        
        // Perform queue operations
        queue.enqueue(10); // Adds 10 to the queue
        queue.enqueue(20); // Adds 20 to the queue
        queue.enqueue(30); // Adds 30 to the queue
        queue.enqueue(40); // Adds 40 to the queue
        queue.enqueue(50); // Adds 50 to the queue
        
        // Display queue
        queue.display(); // Displays the current elements in the queue
        
        // Peek front element
        System.out.println("\nFront element is " + queue.peek()); // Displays the front element of the queue
        
        // Dequeue elements
        System.out.println("\n" + queue.dequeue() + " removed from queue"); // Removes and prints the front element from the queue
        System.out.println("\n" + queue.dequeue() + " removed from queue"); // Removes and prints the next front element from the queue
        
        // Display queue
        queue.display(); // Displays the current elements in the queue after dequeue operations
        
        // Check if queue is empty
        System.out.println("\nIs queue empty? " + queue.isEmpty()); // Checks and prints if the queue is empty
    }
}
