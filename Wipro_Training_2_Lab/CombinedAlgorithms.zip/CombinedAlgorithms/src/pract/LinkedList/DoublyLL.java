package pract.LinkedList; // Declares the package name

// Class to represent a node in the Doubly Linked List
class Node1 {
    int data;       // Data held by the node
    Node1 next;     // Reference to the next node in the list
    Node1 prev;     // Reference to the previous node in the list
    
    // Constructor to initialize a node with data
    Node1(int data) {
        this.data = data;   // Initialize the node with the given data
        this.next = null;   // Initialize next pointer to null (no next node yet)
        this.prev = null;   // Initialize previous pointer to null (no previous node yet)
    }
}

// Class to represent a Doubly Linked List
class DoublyLL {
    Node1 head; // Reference to the first node in the list
    
    // Method to insert a new node with given data at the end of the list
    void insert(int data) {
        Node1 newNode = new Node1(data); // Create a new node with the given data
        
        // If the list is empty, make the new node the head
        if (head == null) {
            head = newNode; // Set the new node as the head
        } else {
            Node1 temp = head;           // Start from the head node
            // Traverse to the last node in the list
            while (temp.next != null) {
                temp = temp.next;        // Move to the next node until the last node is found
            }
            // Add the new node at the end of the list
            temp.next = newNode;         // Link the last node's next to the new node
            newNode.prev = temp;         // Set the previous pointer of the new node to the last node
        }
    }
    
    // Method to display all nodes in the doubly linked list from head to end
    void display() {
        Node1 temp = head;               // Start from the head node
        // Traverse and print each node's data until we reach the end of the list
        while (temp != null) {
            System.out.print(temp.data + " "); // Print the data of the current node
            temp = temp.next;                 // Move to the next node
        }
        System.out.println();                 // Print a newline after displaying the list
    }
    
    public static void main(String[] args) {
        DoublyLL list = new DoublyLL(); // Create a new doubly linked list
        list.insert(1); // Insert nodes with data 1, 2, and 3
        list.insert(2);
        list.insert(3);
        list.display(); // Display the doubly linked list: Output: 1 2 3
    }
}
