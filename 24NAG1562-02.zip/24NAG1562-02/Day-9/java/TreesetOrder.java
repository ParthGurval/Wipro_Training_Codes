
// Arrange the  Strings in TreeSet in DESC order

package com.wipro.java.maps;

import java.util.Scanner;
import java.util.TreeSet;

public class TreesetOrder {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		TreeSet<String> discOrder = new TreeSet<>();
		
		
		System.out.println("Please Enter String (type 'exit' to close insertion) :");
		
		String userInp;
		
		while(!(userInp = sc.nextLine()).equalsIgnoreCase("exit")) {
			
			discOrder.add(userInp);
		}
		
		String[] newArr = new String[discOrder.size()];
		discOrder.toArray(newArr);
		
		System.out.println("List of Elements in DESC order: ");
		
		for(int i = newArr.length - 1; i >= 0; i--) {
			
			System.out.println(newArr[i]);
		}
		sc.close();
	}
}
