package pract.stack;

// Define the Stack class
public class Stack {
    private int[] stack; // Array to hold stack elements
    private int top; // Index of the top element
    private int capacity; // Maximum size of the stack

    // Constructor to initialize stack
    public Stack(int size) {
        capacity = size; // Set the stack's capacity
        stack = new int[capacity]; // Create the stack array
        top = -1; // Stack is empty initially
    }
    
    // Push operation: Adds an element to the top of the stack
    public void push(int value) {
        if (top == capacity - 1) { // Check if stack is full
            System.out.println("Stack Overflow"); // Print error message
            return;
        }
        stack[++top] = value; // Increment top and add the new value
        System.out.println("\n"+ value + " pushed to stack"); // Print confirmation
    }
    
    // Pop operation: Removes and returns the top element from the stack
    public int pop() {
        if (isEmpty()) { // Check if stack is empty
            System.out.println("Stack Underflow"); // Print error message
            return -1; // Return -1 to indicate error
        }
        return stack[top--]; // Return top element and decrement top
    }
    
    // Peek operation: Returns the top element without removing it
    public int peek() {
        if (isEmpty()) { // Check if stack is empty
            System.out.println("Stack is empty"); // Print error message
            return -1; // Return -1 to indicate error
        }
        return stack[top]; // Return top element
    }
    
    // Check if stack is empty
    public boolean isEmpty() {
        return top == -1; // Return true if top is -1 (stack is empty)
    }
    
    // Display the stack elements
    public void display() {
        if (isEmpty()) { // Check if stack is empty
            System.out.println("\nStack is empty"); // Print message if empty
            return;
        }
        System.out.print("\nStack elements: "); // Print header
        for (int i = 0; i <= top; i++) { // Loop through stack elements
            System.out.print(stack[i] + " "); // Print each element
        }
        System.out.println(); // Print newline at the end
    }
    
    public static void main(String[] args) {
        // Create a stack of size 5
        Stack stack = new Stack(5);
        
        // Perform stack operations
        stack.push(10); // Push 10 to stack
        stack.push(20); // Push 20 to stack
        stack.push(30); // Push 30 to stack
        stack.push(40); // Push 40 to stack
        stack.push(50); // Push 50 to stack
        
        // Display stack
        stack.display(); // Output: Stack elements: 10 20 30 40 50 
        
        // Peek top element
        System.out.println("\nTop element is " + stack.peek()); // Output: Top element is 50
        
        // Pop elements
        System.out.println("\n"+stack.pop() + " popped from stack"); // Output: 50 popped from stack
        System.out.println("\n"+stack.pop() + " popped from stack"); // Output: 40 popped from stack
        
        // Display stack
        stack.display(); // Output: Stack elements: 10 20 30
        
        // Check if stack is empty
        System.out.println("\nIs stack empty? " + stack.isEmpty()); // Output: Is stack empty? false
    }
}
