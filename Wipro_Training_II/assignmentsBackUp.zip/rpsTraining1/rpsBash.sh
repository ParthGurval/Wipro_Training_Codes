#!/bin/bash

echo "This is my First Comment using Bash"

firstVar=rpsBatch1

echo "The name of my BAtch is: " $firstVar

trainer=$firstVar

echo "The Training program is under: " $trainer

echo "Please Enter Your First Name: "
read firstName

echo "Please Enter Your Last Name: "
read lastName

echo "The Full name is: " $firstName $lastName

echo $(date)


