
// Programs to remove all the duplicates from string and Count the Repeated Characters in string

package com.wipro.java.maps;

import java.util.Scanner;
import java.util.Map;
import java.util.HashMap;
import java.util.HashSet; 


public class RepeatedChar {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		HashMap<Character, Integer> finalHash = new HashMap<>();
		HashSet<Character> uniqueChars = new HashSet<>();
		char choice;
		
		do {
			
			System.out.print("Please Enter a String: ");
			String strInp = sc.next(); 
			
			finalHash.clear();
			uniqueChars.clear();
			
			for(int i = 0; i < strInp.length(); i++) {
				
				char ch = strInp.charAt(i);
				finalHash.put(ch, finalHash.getOrDefault(ch, 0) + 1);
				uniqueChars.add(ch);
			}
			
			System.out.println("Characters and Its Count are: ");
			
			for(char key : finalHash.keySet()) {
				
				System.out.println(key+ " = " +finalHash.get(key));
			}
			
			System.out.println("String Without Repeated Character: ");
			for(char ch : uniqueChars) {
				System.out.print(ch);
			}
			System.out.println();
			
			System.out.println("Do you want to add another String? (y/n): ");
			choice = sc.next().charAt(0);
		}
		
		while(choice == 'Y' || choice == 'y');
			
			System.out.println("Thank You... :-)");
			sc.close();
		
	}
	
}
