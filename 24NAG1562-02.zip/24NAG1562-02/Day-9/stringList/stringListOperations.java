
/*
 
  Write a simple java program that accepts List of Strings from user
  The program should accept the inputs Strings until user enter exit
  After collecting Strings perform following operations:
 	1. Remove string shorter than 3 character. 
 	2. Convert String at even indices to lowerCase start from index 0.
 	3. Convert String at odd indices to upperCase.
 	4. Convert String which end with vowels.
 	5. Remove String which contains digits. 
 */


package com.wipro.stringList;

import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class stringListOperations {
	
	private static boolean vowelReverse(String str) {
		
		char lastChar = Character.toLowerCase(str.charAt(str.length() - 1));
		return lastChar == 'a' || lastChar == 'e' || lastChar == 'i' || lastChar == 'o' || lastChar == 'u';
	}
	
	private static String StringReverse(String str) {
		
		StringBuilder sb = new StringBuilder(str);
		return sb.reverse().toString();
	}
	
	private static boolean checkDigit(String str) {
		
		if(str == null || str.isEmpty()) {
			
			return false;
		}
		
		for(char c : str.toCharArray()) {
			if(Character.isDigit(c)) {
				return true;
			}
		}
		
		return false;
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		List<String> strList = new ArrayList<>();
		
		System.out.println("Please Enter the String (Type 'exit' to close): ");
		
		while(true) {
			
			String inp = sc.nextLine();
			
			if(inp.equalsIgnoreCase("exit")) {
				break;
			}
			
			strList.add(inp);
		}
		
		System.out.println("The initial String List is: "+strList);
		
		for(int i = 0; i < strList.size(); i++) {
			
			String str = strList.get(i);
			
			//shorter than 3
			if(str.length() < 3) {
				
				strList.remove(i);
				i--;
				continue;
			}
			
			boolean vowelReverse = vowelReverse(str);
			
			//even index & odd index
			if(i % 2 == 0) {
				
				if(vowelReverse) {
					
					strList.set(i, StringReverse(str).toLowerCase());
				}
				else {
					strList.set(i, str.toLowerCase());
				}
			}
			else {
				
				if(vowelReverse) {
					
					strList.set(i, StringReverse(str).toUpperCase());
				}
				else {
					strList.set(i, str.toUpperCase());
				}
				
			}
			
			//reverse element which end with vowel
			if(vowelReverse(str)) {
				
				strList.set(i, StringReverse(str));
			}
			
			if(checkDigit(str)) {
				
				strList.remove(i);
				i--;
			}
		}			
		
		System.out.println("The Updated String list: ");
		System.out.println(strList);
   }
}