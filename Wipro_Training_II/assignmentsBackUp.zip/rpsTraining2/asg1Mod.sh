#!/bin/bash

echo "Enter File name separated by space not coma: "

read -r inpFile

filenames=($inpFile)

start_dir="$HOME"

for filename in "${filenames[@]}"; do

	if find "$start_dir" -type f -name "$filename" > /dev/null 2>&1; then
		echo "File exists"
	else
		echo "File not found"
	fi
done
