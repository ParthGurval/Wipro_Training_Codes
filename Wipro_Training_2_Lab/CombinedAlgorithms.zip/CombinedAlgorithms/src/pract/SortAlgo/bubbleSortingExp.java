package pract.SortAlgo;

public class bubbleSortingExp {

    // Method to perform Bubble Sort on an array
    public static void bubbleSort(int[] array) {
        
        int n = array.length; // Get the length of the array
        boolean swapped; // Flag to check if any elements were swapped
        
        // Traverse through all array elements
        for(int i = 0; i < n - 1; i++) {
            
            swapped = false; // Reset swapped flag for this pass
            
            // Perform the comparisons and swaps
            for(int j = 0; j < n - i - 1; j++) {
                
                // Compare the current element with the next element
                if(array[j] > array[j + 1]) {
                    
                    // Swap if the current element is greater than the next
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    
                    swapped = true; // Set swapped flag to true
                }
            }
            
            // If no elements were swapped, the array is already sorted
            if(!swapped) break;
        }
    }
    
    // Method to print the array
    public static void printArr(int[] arr, int size) {
        // Loop through each element and print it
        for(int i = 0; i < size ; i++) {
            System.out.print(arr[i] + " ");
        }
    }

    public static void main(String[] args) {
        // Define an array of integers to be sorted
        int[] num = {89, 68, 21, 10, 45, 20, 9, 53, 24, 98, 90}; 
        int l = num.length; // Get the length of the array
        
        // Print the original array
        System.out.println("The Original Array is: ");
        printArr(num, l);
        
        System.out.println();
        
        // Sort the array using Bubble Sort
        bubbleSort(num);
        
        // Print the sorted array
        System.out.println("\nThe Bubble Sorted Array is: ");
        printArr(num, l);
    }
}

