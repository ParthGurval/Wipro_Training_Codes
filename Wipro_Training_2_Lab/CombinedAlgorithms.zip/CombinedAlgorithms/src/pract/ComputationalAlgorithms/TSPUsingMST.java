package pract.ComputationalAlgorithms;

import java.util.*;

public class TSPUsingMST {

    public static void main(String[] args) {
        // Purpose: Main method to execute the TSP solution using MST approximation
        
        // Purpose: Define the graph representing distances between cities
        int[][] graph = {
            // Explanation: Each row and column represent a city, and the values represent the distance between cities
            {0, 10, 15, 20},
            {10, 0, 35, 25},
            {15, 35, 0, 30},
            {20, 25, 30, 0}
        };
        
        // Purpose: Calculate and print the approximate TSP cost using the MST-based method
        System.out.println("Approximate TSP cost (using MST): " + calcTSPCost(graph));
    }

    // Purpose: Calculate the approximate TSP cost using a Minimum Spanning Tree (MST) approach
    // Parameters:
    //   - int[][] graph: The adjacency matrix representing the graph
    // Returns: The approximate TSP cost based on the MST
    static int calcTSPCost(int[][] graph) {
        
        int n = graph.length;  // Explanation: Number of cities (nodes) in the graph
        
        // Purpose: Initialize an array to keep track of visited nodes
        boolean[] visited = new boolean[n];
        
        // Purpose: Initialize an array to store the minimum edge weight to connect a node to the MST
        int[] key = new int[n];
        
        // Purpose: Initialize an array to store the parent of each node in the MST
        int[] parent = new int[n];
        
        // Purpose: Fill the `key` array with a large value to represent infinity (unreachable nodes)
        Arrays.fill(key, Integer.MAX_VALUE);
        
        // Purpose: Start the MST from the first node (node 0)
        key[0] = 0;
        parent[0] = -1;  // Explanation: Root node of MST has no parent
        
        // Purpose: Create a priority queue to pick the next minimum edge
        PriorityQueue<Integer> pq = new PriorityQueue<>(Comparator.comparingInt(i -> key[i]));
        
        // Purpose: Add the starting node (0) to the priority queue
        pq.add(0);
        
        // Purpose: Loop until the priority queue is empty (all nodes are added to the MST)
        while (!pq.isEmpty()) {
            
            // Purpose: Extract the node with the minimum key value from the priority queue
            int u = pq.poll();
            visited[u] = true;  // Explanation: Mark this node as visited
            
            // Purpose: Iterate through all adjacent nodes of the extracted node
            for (int v = 0; v < n; v++) {
                
                // Purpose: Check if there is an edge from `u` to `v` and `v` is not yet included in the MST
                if (graph[u][v] != 0 && !visited[v] && graph[u][v] < key[v]) {
                    
                    // Explanation: Update the key value and parent for node `v`
                    key[v] = graph[u][v];
                    pq.add(v);  // Explanation: Add `v` to the priority queue for further processing
                    parent[v] = u;  // Explanation: Update parent of `v` to be `u` in the MST
                }
            }
        }
        
        int mstWeight = 0;  // Explanation: Initialize the total weight of the MST
        
        // Purpose: Calculate the total weight of the constructed MST
        for (int i = 1; i < n; i++) {
            mstWeight += graph[i][parent[i]];  // Explanation: Add the weight of each edge in the MST
        }
        
        // Purpose: Return the approximate TSP cost, which is twice the weight of the MST
        return 2 * mstWeight;
    }
}

