package com.wipro.hashMap;

import java.util.HashMap;

public class PairCalculation {

	public static void main(String[] args) {
		
		String inp = "book keeper";
		System.out.println("Given String is: "+inp);
		
		int finalPairs = allConsecutivePairs(inp);
		
		System.out.println("The Number of Pairs are: "+finalPairs);
	}
	
	public static int allConsecutivePairs(String str) {
		
		HashMap<String, Integer> calPair = new HashMap<>();
		
		for(int i = 0; i < str.length() - 1; i++) {
			
			String thePair = str.substring(i, i+2);
			
			calPair.put(thePair, calPair.getOrDefault(thePair, 0) + 1);
		}
		
		int count = 0;
		
		for(int val : calPair.values()) {
			
			if(val > 1) {
			
				count ++;
			}
		}
		
		return count;
	}
}
