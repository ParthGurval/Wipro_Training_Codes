#!/bin/bash

# Assignment 4

dir_name="TestDir"
file_prefix="File"
file_extension=".txt"

mkdir -p "$dir_name"

for i in {1..10}; do
	file_name="${file_prefix}${i}${file_extension}"
	echo "file_name" > "${dir_name}/${file_name}"
done

echo "Directory '$dir_name' and files created sucessfully..." 
