#!/bin/bash

number=train
batch=train
blank=

if [ $number = $batch ] ; then
echo "value is equal"
else
echo "value is not equal"
fi

if [ -n $number ] ; then
echo "value is not empty"
fi

if [ -z $blank ] ; then
echo "value is blank"
fi


