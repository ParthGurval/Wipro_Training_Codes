package pract.SearchingAlgo;

import java.util.Scanner;

public class BinarySrch {
    
    // Method to perform binary search on a sorted array
    public static int binSearch(int[] array, int num) {
        
        int low = 0; // Starting index of the search range
        int high = array.length - 1; // Ending index of the search range
        
        // Loop until the search range is valid
        while(low <= high) {
            
            // Calculate the middle index of the current search range
            int mid = low + (high - low) / 2;
            
            // Check if the middle element is the target number
            if(array[mid] == num) {
                return mid; // Return the index of the found number
            }
            
            // If the target number is greater than the middle element,
            // search in the right half of the array
            else if(array[mid] < num) {
                low = mid + 1; // Update the starting index of the search range
            }
            
            // If the target number is smaller than the middle element,
            // search in the left half of the array
            else {
                high = mid - 1; // Update the ending index of the search range
            }
        }
        
        // Return -1 if the number is not found in the array
        return -1;
    }

    public static void main(String[] args) {
        // Create a Scanner object to read input from the user
        Scanner sc = new Scanner(System.in);
        
        // Define a sorted array for binary search
        int[] arr = {0, 5, 10, 15, 20, 25, 50, 75, 100, 150, 200, 400, 900};
        
        // Prompt the user to enter the number they want to search for
        System.out.print("Please enter the number you want to search: ");
        int num = sc.nextInt(); // Read the user input
        
        // Call the binary search method and store the result
        int res = binSearch(arr, num);
        
        // Check if the number was found and print the appropriate message
        if(res != -1) {
            System.out.println("The Number " + num + " is found in the array at index: " + res);
        } else {
            System.out.println("The number is not present in the array");
        }
        
        // Close the Scanner to prevent resource leaks
        sc.close();
    }
}

