package pract.GraphAlgorithms;

import java.util.*;

public class DijkstraAlgoCode {
	
    // Method to perform Dijkstra's algorithm
    public static int[] dijkstra(int[][] graph, int source) {
        // Argument graph: 2D array representing the adjacency matrix of the graph
        // Argument source: The starting vertex for which shortest paths are computed
        
        int n = graph.length; // Number of vertices in the graph
        
        int[] dist = new int[n]; // Array to store the shortest distance from source to each vertex
        
        boolean[] visited = new boolean[n]; // Array to track visited vertices
        
        Arrays.fill(dist, Integer.MAX_VALUE); // Initialize all distances as infinity
        dist[source] = 0; // Distance to the source vertex is zero
        
        // Loop to find the shortest path for all vertices
        for (int i = 0; i < n - 1; i++) {
            // Find the vertex with the minimum distance value from the set of vertices not yet processed
            int u = minDist(dist, visited);
            
            visited[u] = true; // Mark the selected vertex as visited
            
            // Update the distance value of the adjacent vertices of the selected vertex
            for (int v = 0; v < n; v++) {
                // Check if there is an edge from u to v, and the vertex v is not yet processed
                // Also check if the total distance from source to v through u is smaller
                if (!visited[v] && graph[u][v] != 0 && dist[u] != Integer.MAX_VALUE && dist[u] + graph[u][v] < dist[v]) {
                    dist[v] = dist[u] + graph[u][v]; // Update the distance to vertex v
                }
            }
        }
        
        return dist; // Return the array containing shortest distances from the source
    }
    
    // Method to find the vertex with the minimum distance value from the set of vertices not yet processed
    public static int minDist(int[] dist, boolean[] visited) {
        // Argument dist: Array containing the shortest distances from the source vertex
        // Argument visited: Array indicating whether a vertex has been processed
        
        int min = Integer.MAX_VALUE; // Initialize minimum distance value
        int minIndex = -1; // Initialize index of the vertex with minimum distance
        
        // Loop to find the vertex with the smallest distance value
        for (int v = 0; v < dist.length; v++) {
            // Check if the vertex is not yet processed and has a smaller distance value
            if (!visited[v] && dist[v] <= min) {
                min = dist[v]; // Update minimum distance value
                minIndex = v; // Update index of the vertex with minimum distance
            }
        }
        
        return minIndex; // Return the index of the vertex with the minimum distance value
    }
    
    // Method to display the shortest distances from the source vertex
    public static void displaySoln(int[] dist) {
        // Argument dist: Array containing shortest distances from the source vertex
        
        System.out.println("Vertex \t\t Distance from source");
        
        // Loop to print the vertex number and its shortest distance from the source
        for (int i = 0; i < dist.length; i++) {
            System.out.println(i + " \t\t " + dist[i]);
        }
    }
    
    // Method to get the shortest distance to a specific node
    public static int shortestPath(int[] dist, int node) {
        // Argument dist: Array containing shortest distances from the source vertex
        // Argument node: The target vertex for which the shortest distance is queried
        
        return dist[node]; // Return the shortest distance to the target vertex
    }

    public static void main(String[] args) {
        // Example graph represented by an adjacency matrix
        int[][] graph = {
            {0, 4, 0, 0, 0, 0, 0, 8, 0},
            {4, 0, 8, 0, 0, 0, 0, 11, 0},
            {0, 8, 0, 7, 0, 4, 0, 0, 2},
            {0, 0, 7, 0, 9, 14, 0, 0, 0},
            {0, 0, 0, 9, 0, 10, 0, 0, 0},
            {0, 0, 4, 14, 10, 0, 2, 0, 0},
            {0, 0, 0, 0, 0, 2, 0, 1, 6},
            {8, 11, 0, 0, 0, 0, 1, 0, 7},
            {0, 0, 2, 0, 0, 0, 6, 7, 0}
        };
        
        // Calculate shortest distances from vertex 0
        int[] totDist = dijkstra(graph, 0);
        
        // Display the shortest distances from vertex 0
        displaySoln(totDist);
        
        // Target node for which shortest distance is to be queried
        int tgtNode = 4;
        
        // Print the shortest distance from vertex 0 to the target node
        System.out.println("\nShortest Distance from node 0 to node " + tgtNode + " is: " + shortestPath(totDist, tgtNode));
    }
}

