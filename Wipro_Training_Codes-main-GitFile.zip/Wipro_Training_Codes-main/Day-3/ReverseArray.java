

// Task-5: Reverse an Array

// 1. Create a method to reverse an array

// Reverse The Array

import java.util.Arrays;

public class ReverseArray {
    
    public static int[] arrayReverse(int[] arr){
        
        // int start = 0;
        // int end = arr.length-1;
        
        // while(start < end){
            
        //     int temp = arr[start];
        //     arr[start] = arr[end];
        //     arr[end] = temp;
            
        //     start++;
        //     end--;
        // }
        
        int[] reverse = new int[arr.length];
        
        for(int i=0; i < arr.length; i++){
            reverse[i] = arr[arr.length - 1 - i];
        }
        
        return reverse;
    }
    
    public static void main(String[] args){
        
        int[] array = {6, 3, 7, 2, 5, 7};
        
        System.out.println("The original Array is: " + Arrays.toString(array));
        
        int[] result = arrayReverse(array);
        
        System.out.println("The Reversed Array is: " + Arrays.toString(result));
    }
}