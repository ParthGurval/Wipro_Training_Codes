#!/bin/bash

:<< 'Assignment2'
	Write a script that reads number from the user until they ender 0.
	The Script should also print whether each number is even or odd.

Assignment2

while true; do

	echo "Please Enter a Number (Enter 0 to exit):"
	read inpNum

	if [ $inpNum -eq 0 ]; then
		echo "Script got Exited."
		break
	fi

	if [ $((inpNum % 2)) -eq 0 ]; then
		echo "$inpNum is Even."
	else
		echo "$inpNum is odd."
	fi
done

