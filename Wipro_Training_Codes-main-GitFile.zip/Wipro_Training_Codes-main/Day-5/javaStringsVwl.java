
// 4.Write a method that takes a string, counts the number of vowels, and returns the count.


//Task: 4

import java.util.Scanner;

public class javaStringsVwl {
    
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Please Enter a String: ");
        String inpStr = sc.nextLine();
        
        int countVowel = calcVowels(inpStr);
        System.out.println("The Number of vowels in the String are: "+countVowel);

        sc.close();
    }
    
    public static int calcVowels(String str){
        
        str = str.toLowerCase();
        
        int count = 0;
        
        for(int i = 0; i < str.length(); i++){
            
            char vwChar = str.charAt(i);
            
            if(vwChar == 'a' || vwChar == 'e' || vwChar =='i' || vwChar == 'o' || vwChar == 'u'){
                
                count++;
            }
            
        }
        
        return count;
    }
}