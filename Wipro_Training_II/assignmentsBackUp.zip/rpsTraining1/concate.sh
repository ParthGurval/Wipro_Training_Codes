#!/bin/bash

#create a function

myfunction()
{
return $(($1+$2))

}

myfunction 23 32

myfun()
{

q=parth
q+=apple
echo $q
echo "first" $1
echo "second" $2

echo $1$2

}

myfun were gdfh

