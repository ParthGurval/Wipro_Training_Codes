package com.wipro.students.application;

public class OverAgeException extends Exception {

	private String message;
	
	public OverAgeException(String message) {
		
		this.message = message;
	}
	
	public String getMessage() {
		
		return message;
	}
}
